﻿namespace Aula_10._03
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtRaio = new TextBox();
            lblRaio = new Label();
            lblAltura = new Label();
            lblVolume = new Label();
            txtAltura = new TextBox();
            txtVolume = new TextBox();
            btnCalcular = new Button();
            BtnLimpar = new Button();
            btnFechar = new Button();
            SuspendLayout();
            // 
            // txtRaio
            // 
            txtRaio.Location = new Point(246, 114);
            txtRaio.Name = "txtRaio";
            txtRaio.Size = new Size(283, 31);
            txtRaio.TabIndex = 0;
            txtRaio.Validated += txtRaio_Validated;
            // 
            // lblRaio
            // 
            lblRaio.AutoSize = true;
            lblRaio.Location = new Point(60, 114);
            lblRaio.Name = "lblRaio";
            lblRaio.Size = new Size(47, 25);
            lblRaio.TabIndex = 2;
            lblRaio.Text = "Raio";
            // 
            // lblAltura
            // 
            lblAltura.AutoSize = true;
            lblAltura.Location = new Point(60, 193);
            lblAltura.Name = "lblAltura";
            lblAltura.Size = new Size(59, 25);
            lblAltura.TabIndex = 3;
            lblAltura.Text = "Altura";
            lblAltura.Click += label2_Click;
            // 
            // lblVolume
            // 
            lblVolume.AutoSize = true;
            lblVolume.Location = new Point(60, 287);
            lblVolume.Name = "lblVolume";
            lblVolume.Size = new Size(77, 25);
            lblVolume.TabIndex = 4;
            lblVolume.Text = "Volume ";
            // 
            // txtAltura
            // 
            txtAltura.Location = new Point(246, 193);
            txtAltura.Name = "txtAltura";
            txtAltura.Size = new Size(283, 31);
            txtAltura.TabIndex = 5;
            txtAltura.Validated += txtAltura_Validated;
            // 
            // txtVolume
            // 
            txtVolume.Enabled = false;
            txtVolume.Location = new Point(246, 281);
            txtVolume.Name = "txtVolume";
            txtVolume.Size = new Size(283, 31);
            txtVolume.TabIndex = 6;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(114, 392);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(157, 97);
            btnCalcular.TabIndex = 7;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // BtnLimpar
            // 
            BtnLimpar.Location = new Point(433, 392);
            BtnLimpar.Name = "BtnLimpar";
            BtnLimpar.Size = new Size(157, 97);
            BtnLimpar.TabIndex = 8;
            BtnLimpar.Text = "Limpar";
            BtnLimpar.UseVisualStyleBackColor = true;
            BtnLimpar.Click += BtnLimpar_Click;
            // 
            // btnFechar
            // 
            btnFechar.Location = new Point(744, 392);
            btnFechar.Name = "btnFechar";
            btnFechar.Size = new Size(157, 97);
            btnFechar.TabIndex = 9;
            btnFechar.Text = "Fechar";
            btnFechar.UseVisualStyleBackColor = true;
            btnFechar.Click += btnFechar_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1040, 604);
            Controls.Add(btnFechar);
            Controls.Add(BtnLimpar);
            Controls.Add(btnCalcular);
            Controls.Add(txtVolume);
            Controls.Add(txtAltura);
            Controls.Add(lblVolume);
            Controls.Add(lblAltura);
            Controls.Add(lblRaio);
            Controls.Add(txtRaio);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtRaio;
        private Label lblRaio;
        private Label lblAltura;
        private Label lblVolume;
        private TextBox txtAltura;
        private TextBox txtVolume;
        private Button btnCalcular;
        private Button BtnLimpar;
        private Button btnFechar;
    }
}
