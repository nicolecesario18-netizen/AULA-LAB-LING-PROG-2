namespace Aula_10._03
{
    public partial class Form1 : Form
    {

        double raio, altura, volume; /*globais*/
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {

            if (!double.TryParse(txtRaio.Text, out raio) ||
                    raio <= 0)
            {
                MessageBox.Show("raio inv�lido");
                txtRaio.Focus();
            }

        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {

            if (!double.TryParse(txtAltura.Text, out altura) ||
                    altura <= 0)
            {
                MessageBox.Show("altura inv�lido");
                txtAltura.Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            volume = Math.PI * Math.Pow(raio, 2) * altura;
            txtVolume.Text = volume.ToString("N2");
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();

        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            
            txtVolume.Clear();
            txtAltura.Clear();
            txtRaio.Clear();    
            raio=0; 
            volume = 0;
            altura= 0;
            txtRaio.Focus();
        }
    }
}
