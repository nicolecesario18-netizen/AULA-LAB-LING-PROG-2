﻿namespace PTesteMetodos
{
    partial class frmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnSortear = new Button();
            lblNumero2 = new Label();
            lblNumeo1 = new Label();
            txtNumero2 = new TextBox();
            txtNumero1 = new TextBox();
            SuspendLayout();
            // 
            // btnSortear
            // 
            btnSortear.Location = new Point(89, 193);
            btnSortear.Name = "btnSortear";
            btnSortear.Size = new Size(150, 73);
            btnSortear.TabIndex = 18;
            btnSortear.Text = "Sortear";
            btnSortear.UseVisualStyleBackColor = true;
            btnSortear.Click += btnSortear_Click;
            // 
            // lblNumero2
            // 
            lblNumero2.AutoSize = true;
            lblNumero2.Location = new Point(19, 108);
            lblNumero2.Name = "lblNumero2";
            lblNumero2.Size = new Size(92, 25);
            lblNumero2.TabIndex = 17;
            lblNumero2.Text = "Numero 2";
            // 
            // lblNumeo1
            // 
            lblNumeo1.AutoSize = true;
            lblNumeo1.Location = new Point(19, 37);
            lblNumeo1.Name = "lblNumeo1";
            lblNumeo1.Size = new Size(92, 25);
            lblNumeo1.TabIndex = 16;
            lblNumeo1.Text = "Numero 1";
            // 
            // txtNumero2
            // 
            txtNumero2.Location = new Point(186, 103);
            txtNumero2.Name = "txtNumero2";
            txtNumero2.Size = new Size(148, 31);
            txtNumero2.TabIndex = 15;
            txtNumero2.Validated += txtNumero2_Validated;
            // 
            // txtNumero1
            // 
            txtNumero1.Location = new Point(186, 32);
            txtNumero1.Name = "txtNumero1";
            txtNumero1.Size = new Size(148, 31);
            txtNumero1.TabIndex = 14;
            txtNumero1.TextChanged += txtNumero1_TextChanged;
            txtNumero1.Validated += txtNumero1_Validated;
            // 
            // frmExercicio5
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(699, 491);
            Controls.Add(btnSortear);
            Controls.Add(lblNumero2);
            Controls.Add(lblNumeo1);
            Controls.Add(txtNumero2);
            Controls.Add(txtNumero1);
            Margin = new Padding(4, 5, 4, 5);
            Name = "frmExercicio5";
            Text = "frmExercicio5";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnSortear;
        private Label lblNumero2;
        private Label lblNumeo1;
        private TextBox txtNumero2;
        private TextBox txtNumero1;
    }
}