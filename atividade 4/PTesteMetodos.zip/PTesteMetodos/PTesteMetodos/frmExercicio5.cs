﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        int numero1, numero2;
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            if (numero2 < numero1)
            {
                MessageBox.Show("numero 2 precisa ser maior que numero 1");
                txtNumero1.Focus();
            }
            else
            {
                Random objR = new Random();
                int sorteado = objR.Next(numero1, numero2);
                MessageBox.Show("O numero sorteado é: " + sorteado);
            }
        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (int.TryParse(txtNumero1.Text, out numero1) || (numero1 == 0))
            {
                MessageBox.Show("numero invalido");
                txtNumero1.Focus();
            }
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if (int.TryParse(txtNumero2.Text, out numero2) || (numero2 <= 0))
            {
                MessageBox.Show("numero invalido");
                txtNumero2.Focus();
            }
        }

        private void txtNumero1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
