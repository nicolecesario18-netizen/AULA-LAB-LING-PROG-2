﻿namespace PTesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            rchtxtFrase = new RichTextBox();
            btnContanum = new Button();
            btnLocaliza = new Button();
            btnContaletra = new Button();
            SuspendLayout();
            // 
            // rchtxtFrase
            // 
            rchtxtFrase.Location = new Point(297, 73);
            rchtxtFrase.Name = "rchtxtFrase";
            rchtxtFrase.Size = new Size(414, 234);
            rchtxtFrase.TabIndex = 0;
            rchtxtFrase.Text = "";
            // 
            // btnContanum
            // 
            btnContanum.Location = new Point(126, 364);
            btnContanum.Name = "btnContanum";
            btnContanum.Size = new Size(207, 112);
            btnContanum.TabIndex = 1;
            btnContanum.Text = "Conta Numeros ";
            btnContanum.UseVisualStyleBackColor = true;
            btnContanum.Click += btnContanum_Click;
            // 
            // btnLocaliza
            // 
            btnLocaliza.Location = new Point(379, 364);
            btnLocaliza.Name = "btnLocaliza";
            btnLocaliza.Size = new Size(207, 112);
            btnLocaliza.TabIndex = 2;
            btnLocaliza.Text = "Onde esta o primeiro caracter branco";
            btnLocaliza.UseVisualStyleBackColor = true;
            btnLocaliza.Click += btnLocaliza_Click;
            // 
            // btnContaletra
            // 
            btnContaletra.Location = new Point(634, 364);
            btnContaletra.Name = "btnContaletra";
            btnContaletra.Size = new Size(207, 112);
            btnContaletra.TabIndex = 3;
            btnContaletra.Text = "Conta Letra";
            btnContaletra.UseVisualStyleBackColor = true;
            btnContaletra.Click += btnContaletra_Click;
            // 
            // frmExercicio4
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(975, 579);
            Controls.Add(btnContaletra);
            Controls.Add(btnLocaliza);
            Controls.Add(btnContanum);
            Controls.Add(rchtxtFrase);
            Name = "frmExercicio4";
            Text = "frmExercicio4";
            ResumeLayout(false);
        }

        #endregion

        private RichTextBox rchtxtFrase;
        private Button btnContanum;
        private Button btnLocaliza;
        private Button btnContaletra;
    }
}